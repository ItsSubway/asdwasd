module.exports = () =>{
  console.log('DARKNET SHOP Is Online');
}