module.exports = {
    name: 'say2',
    description: "This is a say command",
    execute(message, args, cmd, client, Discord){
        const sayMessage = args.join(" ");
        message.delete().catch(err => console.log(err));
        let messageArgs = args.join(' ');
        const newEmbed = new Discord.MessageEmbed()
          .setColor('#ff0000')
          //.setAuthor('Gangsters Paradise Reborn')
          .setDescription(messageArgs);
          message.channel.send(newEmbed);
      }
    }