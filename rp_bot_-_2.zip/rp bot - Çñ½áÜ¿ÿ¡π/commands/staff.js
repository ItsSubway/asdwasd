module.exports = {
  name: "staff",
  description: "application URL",
  execute(message, args, cmd, client, Discord) {
        message.delete().catch(err => console.log(err));
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#ff0000')
        .setDescription('[**STAFF APPLICATION**](https://docs.google.com/forms/d/e/1FAIpQLSe5_gYNyyOsLer89vRf9BMYzmtSArYS7DzNRIKJbeBB1q4I6Q/viewform)')
        .setImage('https://cdn.discordapp.com/attachments/891724664869650452/904103465125568613/image0.png')
        .setURL('https://docs.google.com/forms/d/e/1FAIpQLSe5_gYNyyOsLer89vRf9BMYzmtSArYS7DzNRIKJbeBB1q4I6Q/viewform')
        message.channel.send(newEmbed) //so it replys to the `.ping` command
    }
};

